"use strict";
$('#pay-u-button').trigger('click');

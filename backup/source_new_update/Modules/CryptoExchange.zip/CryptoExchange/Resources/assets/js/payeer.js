"use strict";
$('#payeer-submit-button').trigger('click');


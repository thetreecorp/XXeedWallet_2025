<?php

namespace checkmobi;

use Exception;

class CheckMobiError extends Exception
{
    
}
